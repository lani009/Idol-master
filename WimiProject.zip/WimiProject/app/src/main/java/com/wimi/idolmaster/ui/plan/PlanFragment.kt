package com.wimi.idolmaster.ui.plan

import com.wimi.idolmaster.R
import com.wimi.idolmaster.databinding.FragmentPlanBinding
import com.wimi.idolmaster.ui.base.BaseFragment

class PlanFragment : BaseFragment<FragmentPlanBinding, PlanViewModel>(
    R.layout.fragment_plan,
    PlanViewModel::class
) {

    override fun onCreate() {

    }

}