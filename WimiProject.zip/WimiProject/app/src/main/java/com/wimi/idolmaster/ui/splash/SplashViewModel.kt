package com.wimi.idolmaster.ui.splash

import android.app.Application
import com.wimi.idolmaster.ui.base.BaseViewModel

class SplashViewModel(application: Application) : BaseViewModel(application) {

}