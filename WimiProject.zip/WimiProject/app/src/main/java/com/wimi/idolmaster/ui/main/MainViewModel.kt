package com.wimi.idolmaster.ui.main

import android.app.Application
import com.wimi.idolmaster.ui.base.BaseViewModel

class MainViewModel(application: Application): BaseViewModel(application) {

}