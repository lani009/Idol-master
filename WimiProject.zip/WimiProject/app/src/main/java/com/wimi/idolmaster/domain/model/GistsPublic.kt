package com.wimi.idolmaster.domain.model

data class GistsPublic(val url: String, val forks_url: String)