package com.wimi.idolmaster.domain.repository

import com.wimi.idolmaster.domain.core.Result
import com.wimi.idolmaster.domain.model.MyReview
import com.wimi.idolmaster.domain.model.Review
import kotlinx.coroutines.flow.Flow
import okhttp3.ResponseBody
import org.json.JSONObject

interface WimiRepository {
    fun login(id: String): Flow<Result<JSONObject>>
    fun writeReview(id: String, content: String, place: String, summery: String): Flow<Result<JSONObject>>
    fun getReview(place: String): Flow<Result<List<Review>>>
    fun getMyReview(id: String): Flow<Result<List<MyReview>>>
    fun getTasteList(): Flow<Result<List<String>>>
    fun saveReview(id: String, content: String, place: String, summery: String): Flow<Result<ResponseBody>>
}